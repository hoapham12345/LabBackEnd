
using System;
using System.Collections.Generic;

class SinhVien {
    public string MaSV { get; set; }
    public string HoTen { get; set; }
    public double DiemTB { get; set; }

    public SinhVien(string ma, string ten, double diem) {
        MaSV = ma;
        HoTen = ten;
        DiemTB = diem;
    }

    public void HienThi() {
        Console.WriteLine($"Mã SV: {MaSV}, Họ tên: {HoTen}, Điểm TB: {DiemTB}");
    }
}

class Program {
    static void Main() {
        List<SinhVien> ds = new List<SinhVien>();
        ds.Add(new SinhVien("SV01", "Nguyen Van A", 8.0));
        ds.Add(new SinhVien("SV02", "Le Thi B", 7.5));

        foreach (var sv in ds) {
            sv.HienThi();
        }
    }
}
