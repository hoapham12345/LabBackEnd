using System;

class Bai17
{
    static void Main(string[] args)
    {
        Console.WriteLine("Day la bai 17.");
    }
}