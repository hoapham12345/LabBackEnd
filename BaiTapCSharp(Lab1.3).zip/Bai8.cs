using System;

class Bai8
{
    static void Main(string[] args)
    {
        Console.WriteLine("Day la bai 8.");
    }
}