
using System;
using System.Collections.Generic;

class NhanVien {
    public string MaNV { get; set; }
    public string HoTen { get; set; }
    public double Luong { get; set; }

    public NhanVien(string ma, string ten, double luong) {
        MaNV = ma;
        HoTen = ten;
        Luong = luong;
    }

    public void HienThi() {
        Console.WriteLine($"Mã NV: {MaNV}, Họ tên: {HoTen}, Lương: {Luong}");
    }
}

class Program {
    static void Main() {
        List<NhanVien> ds = new List<NhanVien>();
        ds.Add(new NhanVien("NV01", "Tran Van C", 1000));
        ds.Add(new NhanVien("NV02", "Pham Thi D", 1200));

        foreach (var nv in ds) {
            nv.HienThi();
        }
    }
}
