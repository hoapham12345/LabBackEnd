
using System;
using System.Collections.Generic;

class HinhChuNhat {
    public double ChieuDai { get; set; }
    public double ChieuRong { get; set; }

    public HinhChuNhat(double dai, double rong) {
        ChieuDai = dai;
        ChieuRong = rong;
    }

    public double TinhDienTich() {
        return ChieuDai * ChieuRong;
    }

    public void HienThi() {
        Console.WriteLine($"Chiều dài: {ChieuDai}, Chiều rộng: {ChieuRong}, Diện tích: {TinhDienTich()}");
    }
}

class Program {
    static void Main() {
        List<HinhChuNhat> ds = new List<HinhChuNhat>();
        ds.Add(new HinhChuNhat(4.5, 3.2));
        ds.Add(new HinhChuNhat(6.0, 2.5));

        foreach (var hcn in ds) {
            hcn.HienThi();
        }
    }
}
