using System;

class Bai9
{
    static void Main(string[] args)
    {
        Console.WriteLine("Day la bai 9.");
    }
}