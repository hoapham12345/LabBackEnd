using System;

class Bai13
{
    static void Main(string[] args)
    {
        Console.WriteLine("Day la bai 13.");
    }
}