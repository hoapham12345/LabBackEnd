using System;
using System.Collections.Generic;

class Diem
{
    public double X { get; set; }
    public double Y { get; set; }

    public Diem(double x, double y)
    {
        X = x;
        Y = y;
    }

    public double TinhKhoangCach(Diem d)
    {
        return Math.Sqrt(Math.Pow(X - d.X, 2) + Math.Pow(Y - d.Y, 2));
    }

    public override string ToString()
    {
        return $"({X}, {Y})";
    }
}

class Program
{
    static void Main(string[] args)
    {
        Diem d1 = new Diem(2, 3);
        Diem d2 = new Diem(5, 7);
        Console.WriteLine($"Khoang cach: {d1.TinhKhoangCach(d2):F2}");
    }
}