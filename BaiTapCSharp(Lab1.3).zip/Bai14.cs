using System;

class Bai14
{
    static void Main(string[] args)
    {
        Console.WriteLine("Day la bai 14.");
    }
}