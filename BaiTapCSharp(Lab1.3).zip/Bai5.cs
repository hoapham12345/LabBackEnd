using System;
using System.Collections.Generic;

class VanBan
{
    public string NoiDung { get; set; }

    public VanBan(string noiDung)
    {
        NoiDung = noiDung;
    }

    public int DemSoTu()
    {
        return NoiDung.Split(new char[] { ' ', '.', ',', '?', '!' }, StringSplitOptions.RemoveEmptyEntries).Length;
    }

    public override string ToString()
    {
        return NoiDung;
    }
}

class Program
{
    static void Main(string[] args)
    {
        VanBan vb = new VanBan("Day la mot van ban don gian.");
        Console.WriteLine($"So tu trong van ban: {vb.DemSoTu()}");
    }
}