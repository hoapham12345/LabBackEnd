using System;
using System.Collections.Generic;

class PhuongTien
{
    public string HangSanXuat { get; set; }
    public int NamSanXuat { get; set; }

    public PhuongTien(string hangSanXuat, int namSanXuat)
    {
        HangSanXuat = hangSanXuat;
        NamSanXuat = namSanXuat;
    }

    public virtual void HienThi()
    {
        Console.WriteLine($"Hang: {HangSanXuat}, Nam: {NamSanXuat}");
    }
}

class XeHoi : PhuongTien
{
    public string MauSac { get; set; }

    public XeHoi(string hang, int nam, string mau) : base(hang, nam)
    {
        MauSac = mau;
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Mau sac: {MauSac}");
    }
}

class Program
{
    static void Main(string[] args)
    {
        XeHoi xe = new XeHoi("Toyota", 2020, "Do");
        xe.HienThi();
    }
}