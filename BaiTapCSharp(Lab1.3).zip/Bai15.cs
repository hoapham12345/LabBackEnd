using System;

class Bai15
{
    static void Main(string[] args)
    {
        Console.WriteLine("Day la bai 15.");
    }
}