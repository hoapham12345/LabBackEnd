using System;

class Bai16
{
    static void Main(string[] args)
    {
        Console.WriteLine("Day la bai 16.");
    }
}