using System;

class Bai11
{
    static void Main(string[] args)
    {
        Console.WriteLine("Day la bai 11.");
    }
}