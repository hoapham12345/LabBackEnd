using System;

class Bai7
{
    static void Main(string[] args)
    {
        Console.WriteLine("Day la bai 7.");
    }
}