using System;

class Bai10
{
    static void Main(string[] args)
    {
        Console.WriteLine("Day la bai 10.");
    }
}