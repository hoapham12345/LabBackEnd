using System;

class Program
{
    static void Swap(ref int a, ref int b)
    {
        int temp = a;
        a = b;
        b = temp;
    }

    static void Main()
    {
        Console.Write("Nhập số a: ");
        int a = int.Parse(Console.ReadLine());
        Console.Write("Nhập số b: ");
        int b = int.Parse(Console.ReadLine());

        Console.WriteLine($"Trước khi hoán vị: a = {a}, b = {b}");
        Swap(ref a, ref b);
        Console.WriteLine($"Sau khi hoán vị: a = {a}, b = {b}");
    }
}