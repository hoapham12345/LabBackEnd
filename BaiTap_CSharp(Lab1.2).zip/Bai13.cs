using System;

class Program
{
    static void CountPositiveNegative(int[] arr, out int positiveCount, out int negativeCount)
    {
        positiveCount = 0;
        negativeCount = 0;

        foreach (int num in arr)
        {
            if (num > 0)
                positiveCount++;
            else if (num < 0)
                negativeCount++;
        }
    }

    static void Main()
    {
        Console.Write("Nhập số phần tử của mảng: ");
        int n = int.Parse(Console.ReadLine());
        int[] arr = new int[n];

        Console.WriteLine("Nhập các phần tử của mảng:");
        for (int i = 0; i < n; i++)
        {
            arr[i] = int.Parse(Console.ReadLine());
        }

        int positiveCount, negativeCount;
        CountPositiveNegative(arr, out positiveCount, out negativeCount);

        Console.WriteLine($"Số lượng số dương: {positiveCount}");
        Console.WriteLine($"Số lượng số âm: {negativeCount}");
    }
}