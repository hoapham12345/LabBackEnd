using System;

class Program
{
    static void SortArray(double[] arr)
    {
        Array.Sort(arr);
    }

    static void Main()
    {
        Console.Write("Nhập số phần tử của mảng: ");
        int n = int.Parse(Console.ReadLine());
        double[] arr = new double[n];

        Console.WriteLine("Nhập các phần tử của mảng:");
        for (int i = 0; i < n; i++)
        {
            arr[i] = double.Parse(Console.ReadLine());
        }

        SortArray(arr);

        Console.WriteLine("Mảng sau khi sắp xếp theo chiều tăng dần:");
        foreach (double num in arr)
        {
            Console.WriteLine(num);
        }
    }
}