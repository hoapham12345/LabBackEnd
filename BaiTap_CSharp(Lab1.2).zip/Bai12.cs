using System;

class Program
{
    static bool IsPrime(int num)
    {
        if (num <= 1) return false;
        for (int i = 2; i <= Math.Sqrt(num); i++)
        {
            if (num % i == 0)
                return false;
        }
        return true;
    }

    static void Main()
    {
        Console.Write("Nhập số phần tử của mảng: ");
        int n = int.Parse(Console.ReadLine());
        int[] arr = new int[n];

        Console.WriteLine("Nhập các phần tử của mảng:");
        for (int i = 0; i < n; i++)
        {
            arr[i] = int.Parse(Console.ReadLine());
        }

        Console.WriteLine("Các phần tử là số nguyên tố trong mảng:");
        for (int i = 0; i < n; i++)
        {
            if (IsPrime(arr[i]))
            {
                Console.WriteLine($"Chỉ số: {i}, Giá trị: {arr[i]}");
            }
        }
    }
}