using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhập năm: ");
        int year = int.Parse(Console.ReadLine());

        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
            Console.WriteLine("Đây là năm nhuận.");
        else
            Console.WriteLine("Đây không phải là năm nhuận.");
    }
}