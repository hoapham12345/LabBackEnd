using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhập một số: ");
        int number = int.Parse(Console.ReadLine());

        if (number > 0)
            Console.WriteLine("Đây là số dương.");
        else if (number < 0)
            Console.WriteLine("Đây là số âm.");
        else
            Console.WriteLine("Đây là số không.");
    }
}