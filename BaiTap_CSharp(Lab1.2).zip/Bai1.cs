using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhập tên: ");
        string name = Console.ReadLine();

        Console.Write("Nhập tuổi: ");
        int age = int.Parse(Console.ReadLine());

        Console.WriteLine($"Xin chào {name}, bạn {age} tuổi!");
    }
}