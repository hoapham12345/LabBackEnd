using System;

class Program
{
    static int SumEvenNumbers(int[] arr)
    {
        int sum = 0;
        foreach (int num in arr)
        {
            if (num % 2 == 0)
            {
                sum += num;
            }
        }
        return sum;
    }

    static void Main()
    {
        int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        int result = SumEvenNumbers(arr);
        Console.WriteLine($"Tổng các số chẵn trong mảng là: {result}");
    }
}