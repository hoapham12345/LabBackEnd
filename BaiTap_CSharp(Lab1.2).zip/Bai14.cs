using System;

class Program
{
    static int SecondLargest(int[] arr)
    {
        int first = int.MinValue;
        int second = int.MinValue;

        foreach (int num in arr)
        {
            if (num > first)
            {
                second = first;
                first = num;
            }
            else if (num > second && num != first)
            {
                second = num;
            }
        }

        return second;
    }

    static void Main()
    {
        int[] arr = { 12, 35, 1, 10, 34, 1 };
        int result = SecondLargest(arr);
        Console.WriteLine($"Số lớn thứ hai trong mảng là: {result}");
    }
}