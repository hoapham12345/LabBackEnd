using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhập một số nguyên: ");
        int number = int.Parse(Console.ReadLine());

        if (number % 2 == 0)
            Console.WriteLine("Số này là số chẵn.");
        else
            Console.WriteLine("Số này là số lẻ.");
    }
}