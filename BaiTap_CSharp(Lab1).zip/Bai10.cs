using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhập một số: ");
        int number = int.Parse(Console.ReadLine());

        bool isPrime = true;

        if (number <= 1)
            isPrime = false;
        else
        {
            for (int i = 2; i <= Math.Sqrt(number); i++)
            {
                if (number % i == 0)
                {
                    isPrime = false;
                    break;
                }
            }
        }

        if (isPrime)
            Console.WriteLine("Đây là số nguyên tố.");
        else
            Console.WriteLine("Đây không phải là số nguyên tố.");
    }
}