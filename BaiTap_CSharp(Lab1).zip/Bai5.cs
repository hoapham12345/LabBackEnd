using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhập số thứ nhất: ");
        int num1 = int.Parse(Console.ReadLine());

        Console.Write("Nhập số thứ hai: ");
        int num2 = int.Parse(Console.ReadLine());

        int sum = num1 + num2;
        int product = num1 * num2;

        Console.WriteLine($"Tổng: {sum}");
        Console.WriteLine($"Tích: {product}");
    }
}