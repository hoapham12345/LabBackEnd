using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhập chiều dài: ");
        double length = double.Parse(Console.ReadLine());

        Console.Write("Nhập chiều rộng: ");
        double width = double.Parse(Console.ReadLine());

        double area = length * width;
        Console.WriteLine($"Diện tích hình chữ nhật là: {area}");
    }
}